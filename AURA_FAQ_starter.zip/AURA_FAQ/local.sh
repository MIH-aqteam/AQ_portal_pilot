#!/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"
/usr/bin/python3 -m sphinx -b html -n -W --keep-going source build/html
echo "Open build/html/index.html in your browser."
