/* Filter the left navigation using only each FAQ page's Keywords field. */
document.addEventListener("DOMContentLoaded", function () {
  const keywordIndex = window.AURA_FAQ_KEYWORDS || {};
  const sidebar = document.querySelector(".wy-nav-side");
  const searchArea = document.querySelector(".wy-side-nav-search");
  if (!sidebar || !searchArea) return;

  // Replace Sphinx's full-text search with the FAQ keyword filter.
  const fullTextForm = searchArea.querySelector("form");
  if (fullTextForm) fullTextForm.remove();

  const field = document.createElement("div");
  field.className = "faq-keyword-filter";
  const label = document.createElement("label");
  label.htmlFor = "faq-keyword-input";
  label.textContent = "Filter FAQ by keyword";
  const input = document.createElement("input");
  input.id = "faq-keyword-input";
  input.type = "search";
  input.placeholder = "e.g. format or date";
  input.autocomplete = "off";
  const hint = document.createElement("small");
  hint.textContent = "Separate multiple keywords with commas";
  field.append(label, input, hint);
  searchArea.appendChild(field);

  const links = Array.from(sidebar.querySelectorAll(".wy-menu-vertical a[href]"));
  const questions = links.map(function (link) {
    const path = new URL(link.href, document.baseURI).pathname;
    const key = Object.keys(keywordIndex).find(function (name) {
      return path.endsWith("/" + name);
    });
    return key ? { item: link.closest("li"), keywords: keywordIndex[key] } : null;
  }).filter(function (entry) { return entry && entry.item; });

  const noResults = document.createElement("p");
  noResults.className = "faq-no-results";
  noResults.textContent = "No questions match these keywords.";
  noResults.hidden = true;
  const menu = sidebar.querySelector(".wy-menu-vertical");
  if (menu) menu.appendChild(noResults);

  function normalize(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }

  function filterQuestions() {
    const terms = input.value.split(",").map(normalize).filter(Boolean);
    let count = 0;
    questions.forEach(function (entry) {
      const keywords = entry.keywords.map(normalize);
      const show = terms.every(function (term) {
        return keywords.some(function (keyword) { return keyword.includes(term); });
      });
      entry.item.hidden = !show;
      if (show) count++;
    });
    noResults.hidden = terms.length === 0 || count > 0;
    try { sessionStorage.setItem("aura-faq-keyword-filter", input.value); } catch (error) { /* Storage is optional. */ }
  }

  try { input.value = sessionStorage.getItem("aura-faq-keyword-filter") || ""; } catch (error) { /* Storage is optional. */ }
  input.addEventListener("input", filterQuestions);
  filterQuestions();
});
