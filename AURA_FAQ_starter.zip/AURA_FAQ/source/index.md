# AURA FAQ

Type a keyword in the left column to show matching questions. You can enter several keywords separated by commas; a question appears when all entered keywords match its keyword list. Clear the field to see all questions. The FAQ has no categories.

The entries below are **illustrative examples**. Review their wording and links before publication.

```{toctree}
:maxdepth: 1

faq/which-guide
faq/find-attribute
faq/related-tables
faq/date-format
faq/validation-message
faq/find-examples
faq/report-correction
faq/pdf-version
```
