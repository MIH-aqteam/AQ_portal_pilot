# How can I report an error in a guide?

**Date:** 2026-09-23  
**Keywords:** correction, modification, register, error, feedback, request, helpdesk

**Question:** How can I report an error in a guide?

**Answer:** Note the guide, page, and exact passage, then describe the correction you propose. Consult the Correction & Modification Register to see whether it has already been recorded. Contact the AQ IPR helpdesk with the details if it has not.
