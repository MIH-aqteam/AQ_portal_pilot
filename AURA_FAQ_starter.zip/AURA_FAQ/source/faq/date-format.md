# What format should I use for a date or datetime?

**Date:** 2026-09-23  
**Keywords:** format, date, datetime, ISO 8601, UTC offset, time

**Question:** What format should I use for a date or datetime?

**Answer:** For attributes with ReportNet3 data type `date` or `datetime`, use ISO 8601. A datetime value may include a local UTC offset. Check the attribute description for any additional requirement specific to that field.
