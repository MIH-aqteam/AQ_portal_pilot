# Where can I find reporting examples?

**Date:** 2026-09-23  
**Keywords:** example, workbook, Excel, worksheet, reporting, download

**Question:** Where can I find reporting examples?

**Answer:** Check the relevant table page in the Reporting Guide. Where an example workbook is available, the page provides a link and identifies the corresponding worksheet. An unavailable workbook should be marked as such on the page.
