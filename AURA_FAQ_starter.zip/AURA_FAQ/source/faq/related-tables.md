# What does “Related table(s)” mean?

**Date:** 2026-09-23  
**Keywords:** related, tables, link, relationship, reference

**Question:** What does “Related table(s)” mean?

**Answer:** It points to other tables relevant to the attribute you are reading. Where the table name is a link, select it to open that table's page. Check the description of each table to understand how its information relates to your reporting case.
