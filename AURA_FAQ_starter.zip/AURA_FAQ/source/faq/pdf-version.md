# Can I read a guide as a PDF?

**Date:** 2026-09-23  
**Keywords:** PDF, print, offline, guide, version

**Question:** Can I read a guide as a PDF?

**Answer:** Use the **PDF version** button in the Reporting or Reference Guide to open the available PDF. For the most recent corrections and working links, consult the online guide as well.
