# What should I do when I receive a validation message?

**Date:** 2026-09-23  
**Keywords:** validation, error, warning, message, troubleshoot, check

**Question:** What should I do when I receive a validation message?

**Answer:** Keep the exact message and identify the affected table, attribute, and record. Compare the value with the relevant guide description. If the reason remains unclear, include those details when asking the AQ IPR helpdesk for assistance.
