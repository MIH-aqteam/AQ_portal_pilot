# Which AURA guide should I use?

**Date:** 2026-09-23  
**Keywords:** guide, reporting, reference, documentation, choose

**Question:** Which AURA guide should I use?

**Answer:** Start with the Reporting Guide when you need to understand how to prepare a report or complete a table. Use the Reference Guide when you need the detailed description of a table or attribute. Links between the guides can take you directly to the corresponding detail.
