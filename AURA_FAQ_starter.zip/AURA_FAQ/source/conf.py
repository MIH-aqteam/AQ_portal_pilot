import json
import re
from pathlib import Path

project = "AURA FAQ"
author = "AURA"
extensions = ["myst_parser"]
source_suffix = {".md": "markdown"}
master_doc = "index"
exclude_patterns = []
html_theme = "sphinx_rtd_theme"
html_title = "AURA FAQ"
html_theme_options = {
    "navigation_depth": 2,
    "collapse_navigation": False,
    "sticky_navigation": True,
}
html_static_path = ["_static"]
html_css_files = ["faq.css"]
html_js_files = ["faq-filter.js"]
templates_path = ["_templates"]

# Read the keywords from the FAQ pages themselves. The sidebar index therefore
# stays in sync when an editor changes the keywords in a Markdown file.
faq_keywords = {}
for faq_file in sorted((Path(__file__).parent / "faq").glob("*.md")):
    source = faq_file.read_text(encoding="utf-8")
    match = re.search(r"^\*\*Keywords:\*\*\s*(.+)$", source, re.MULTILINE)
    if not match:
        raise ValueError(f"Missing Keywords field: {faq_file.name}")
    keywords = [word.strip() for word in match.group(1).split(",") if word.strip()]
    if not keywords:
        raise ValueError(f"Empty Keywords field: {faq_file.name}")
    faq_keywords[f"faq/{faq_file.stem}.html"] = keywords

html_context = {"faq_keywords_json": json.dumps(faq_keywords, ensure_ascii=False)}
