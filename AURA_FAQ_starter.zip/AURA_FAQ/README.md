# AURA FAQ standalone test

This is a separate Sphinx project using the same `sphinx_rtd_theme` layout as the AURA Reporting and Reference Guides. It does not modify either guide.

## First setup on macOS

Unzip the archive, open Terminal, and move into the `AURA_FAQ` folder. Then run:

```bash
chmod +x local.sh
./local.sh
open build/html/index.html
```

The script uses `/usr/bin/python3`, the Python installation used for your guide builds. If it reports a missing module, stop and share the exact error before installing anything.

## Add a question

1. Copy one of the files in `source/faq/` to a short new filename ending in `.md`.
2. Edit the title, date, keywords, question, and answer.
3. Add the new filename (without `.md`) as a line in the `toctree` in `source/index.md`.
4. Run `./local.sh` and check the new question in the left column and in search.

All supplied entries are illustrative examples. Review their wording before publication, and replace or remove entries that are not needed.

## Keyword filtering

The field above the left navigation filters question titles using only the `Keywords` line in each FAQ file. It accepts part of a keyword while you type. For multiple comma-separated words, the entry must match every word. Clear the field to show all entries. The filter stays in place as you navigate between FAQ pages in the same browser tab.
